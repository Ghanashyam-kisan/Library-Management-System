import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Homepage from './pages/Homepage';
import PatientDetails from './pages/PatientDetails';
import DiagnosticInterface from './pages/DiagnosticInterface';

function App() {
  return (
    <Router>
      <div className="min-h-screen bg-gray-50">
        <Navbar />
        <Routes>
          <Route path="/" element={<Homepage />} />
          <Route path="/patient-details" element={<PatientDetails />} />
          <Route path="/diagnostic" element={<DiagnosticInterface />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;