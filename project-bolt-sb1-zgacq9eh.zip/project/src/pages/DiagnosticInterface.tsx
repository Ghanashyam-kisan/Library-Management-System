import React, { useState, useEffect } from 'react';
import { 
  Heart, 
  Activity, 
  Droplets, 
  Scale, 
  Brain, 
  TrendingUp,
  AlertCircle,
  CheckCircle,
  User,
  Calendar
} from 'lucide-react';

interface VitalSigns {
  heartRate: string;
  oxygenLevel: string;
  glucose: string;
  bloodPressureSystolic: string;
  bloodPressureDiastolic: string;
  bmi: string;
}

interface BrainSignals {
  alpha: string;
  beta: string;
  gamma: string;
  theta: string;
  delta: string;
}

interface PatientData {
  firstName: string;
  lastName: string;
  dateOfBirth: string;
  gender: string;
}

const DiagnosticInterface = () => {
  const [patientData, setPatientData] = useState<PatientData | null>(null);
  const [vitalSigns, setVitalSigns] = useState<VitalSigns>({
    heartRate: '',
    oxygenLevel: '',
    glucose: '',
    bloodPressureSystolic: '',
    bloodPressureDiastolic: '',
    bmi: ''
  });

  const [brainSignals, setBrainSignals] = useState<BrainSignals>({
    alpha: '',
    beta: '',
    gamma: '',
    theta: '',
    delta: ''
  });

  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisResults, setAnalysisResults] = useState<any>(null);

  useEffect(() => {
    // Load patient data from localStorage
    const storedData = localStorage.getItem('patientData');
    if (storedData) {
      setPatientData(JSON.parse(storedData));
    }
  }, []);

  const handleVitalSignChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setVitalSigns(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleBrainSignalChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setBrainSignals(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const calculateAge = (dateOfBirth: string): number => {
    const today = new Date();
    const birthDate = new Date(dateOfBirth);
    let age = today.getFullYear() - birthDate.getFullYear();
    const monthDiff = today.getMonth() - birthDate.getMonth();
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
      age--;
    }
    return age;
  };

  const getVitalSignStatus = (type: string, value: string) => {
    const numValue = parseFloat(value);
    if (!numValue) return { status: 'unknown', color: 'gray' };

    switch (type) {
      case 'heartRate':
        if (numValue >= 60 && numValue <= 100) return { status: 'normal', color: 'green' };
        if (numValue < 60 || numValue > 100) return { status: 'abnormal', color: 'red' };
        break;
      case 'oxygenLevel':
        if (numValue >= 95) return { status: 'normal', color: 'green' };
        if (numValue < 95) return { status: 'low', color: 'red' };
        break;
      case 'glucose':
        if (numValue >= 70 && numValue <= 140) return { status: 'normal', color: 'green' };
        if (numValue < 70 || numValue > 140) return { status: 'abnormal', color: 'red' };
        break;
      case 'bmi':
        if (numValue >= 18.5 && numValue <= 24.9) return { status: 'normal', color: 'green' };
        if (numValue < 18.5 || numValue > 24.9) return { status: 'abnormal', color: 'yellow' };
        break;
    }
    return { status: 'unknown', color: 'gray' };
  };

  const runAnalysis = async () => {
    setIsAnalyzing(true);
    
    // Simulate AI analysis
    await new Promise(resolve => setTimeout(resolve, 3000));
    
    // Mock analysis results
    const mockResults = {
      riskLevel: 'Medium',
      primaryConcerns: [
        'Elevated heart rate detected',
        'Blood pressure readings require monitoring'
      ],
      recommendations: [
        'Follow up with cardiologist within 2 weeks',
        'Monitor blood pressure daily',
        'Consider lifestyle modifications'
      ],
      confidence: 85
    };
    
    setAnalysisResults(mockResults);
    setIsAnalyzing(false);
  };

  return (
    <div className="min-h-screen py-8 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="bg-white rounded-xl shadow-sm p-6 mb-8">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <Activity className="h-8 w-8 text-blue-600 mr-3" />
              <div>
                <h1 className="text-2xl font-bold text-gray-900">Diagnostic Interface</h1>
                <p className="text-gray-600">Medical parameter analysis and disease identification</p>
              </div>
            </div>
            {patientData && (
              <div className="text-right">
                <div className="flex items-center text-gray-700 mb-1">
                  <User className="h-4 w-4 mr-1" />
                  <span className="font-medium">
                    {patientData.firstName} {patientData.lastName}
                  </span>
                </div>
                <div className="flex items-center text-gray-500 text-sm">
                  <Calendar className="h-4 w-4 mr-1" />
                  <span>Age: {calculateAge(patientData.dateOfBirth)} • {patientData.gender}</span>
                </div>
              </div>
            )}
          </div>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Vital Signs Input */}
          <div className="lg:col-span-2 space-y-6">
            <div className="bg-white rounded-xl shadow-sm p-6">
              <h2 className="text-xl font-semibold text-gray-900 mb-6 flex items-center">
                <Heart className="h-5 w-5 mr-2 text-red-500" />
                Vital Signs & Health Parameters
              </h2>
              
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Heart Rate (BPM)
                  </label>
                  <div className="relative">
                    <input
                      type="number"
                      name="heartRate"
                      value={vitalSigns.heartRate}
                      onChange={handleVitalSignChange}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                      placeholder="60-100 normal range"
                    />
                    {vitalSigns.heartRate && (
                      <div className={`absolute right-3 top-3 h-3 w-3 rounded-full bg-${getVitalSignStatus('heartRate', vitalSigns.heartRate).color}-500`}></div>
                    )}
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Oxygen Level (%)
                  </label>
                  <div className="relative">
                    <input
                      type="number"
                      name="oxygenLevel"
                      value={vitalSigns.oxygenLevel}
                      onChange={handleVitalSignChange}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                      placeholder="95-100 normal range"
                      min="0"
                      max="100"
                    />
                    {vitalSigns.oxygenLevel && (
                      <div className={`absolute right-3 top-3 h-3 w-3 rounded-full bg-${getVitalSignStatus('oxygenLevel', vitalSigns.oxygenLevel).color}-500`}></div>
                    )}
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Blood Glucose (mg/dL)
                  </label>
                  <div className="relative">
                    <input
                      type="number"
                      name="glucose"
                      value={vitalSigns.glucose}
                      onChange={handleVitalSignChange}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                      placeholder="70-140 normal range"
                    />
                    {vitalSigns.glucose && (
                      <div className={`absolute right-3 top-3 h-3 w-3 rounded-full bg-${getVitalSignStatus('glucose', vitalSigns.glucose).color}-500`}></div>
                    )}
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    BMI
                  </label>
                  <div className="relative">
                    <input
                      type="number"
                      name="bmi"
                      value={vitalSigns.bmi}
                      onChange={handleVitalSignChange}
                      step="0.1"
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                      placeholder="18.5-24.9 normal range"
                    />
                    {vitalSigns.bmi && (
                      <div className={`absolute right-3 top-3 h-3 w-3 rounded-full bg-${getVitalSignStatus('bmi', vitalSigns.bmi).color}-500`}></div>
                    )}
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Blood Pressure (Systolic)
                  </label>
                  <input
                    type="number"
                    name="bloodPressureSystolic"
                    value={vitalSigns.bloodPressureSystolic}
                    onChange={handleVitalSignChange}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    placeholder="120 mmHg"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Blood Pressure (Diastolic)
                  </label>
                  <input
                    type="number"
                    name="bloodPressureDiastolic"
                    value={vitalSigns.bloodPressureDiastolic}
                    onChange={handleVitalSignChange}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    placeholder="80 mmHg"
                  />
                </div>
              </div>
            </div>

            {/* Brain Signals */}
            <div className="bg-white rounded-xl shadow-sm p-6">
              <h2 className="text-xl font-semibold text-gray-900 mb-6 flex items-center">
                <Brain className="h-5 w-5 mr-2 text-purple-500" />
                Neural Signal Analysis
                <span className="ml-2 text-sm font-normal text-gray-500">(Integration Pending)</span>
              </h2>
              
              <div className="grid md:grid-cols-5 gap-4">
                {Object.entries(brainSignals).map(([key, value]) => (
                  <div key={key}>
                    <label className="block text-sm font-medium text-gray-700 mb-2 capitalize">
                      {key} Wave
                    </label>
                    <input
                      type="number"
                      name={key}
                      value={value}
                      onChange={handleBrainSignalChange}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500 bg-gray-50"
                      placeholder="Hz"
                      disabled
                    />
                  </div>
                ))}
              </div>
              <p className="text-sm text-gray-500 mt-4 italic">
                * Brain signal monitoring interface will be integrated by the neural analysis team
              </p>
            </div>
          </div>

          {/* Analysis Panel */}
          <div className="space-y-6">
            <div className="bg-white rounded-xl shadow-sm p-6">
              <h2 className="text-xl font-semibold text-gray-900 mb-6 flex items-center">
                <TrendingUp className="h-5 w-5 mr-2 text-green-500" />
                Analysis & Results
              </h2>

              <button
                onClick={runAnalysis}
                disabled={isAnalyzing || !vitalSigns.heartRate || !vitalSigns.oxygenLevel}
                className="w-full bg-blue-600 text-white py-3 px-4 rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center"
              >
                {isAnalyzing ? (
                  <>
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                    Analyzing...
                  </>
                ) : (
                  'Run AI Analysis'
                )}
              </button>

              {analysisResults && (
                <div className="mt-6 space-y-4">
                  <div className={`p-4 rounded-lg ${
                    analysisResults.riskLevel === 'Low' ? 'bg-green-50 border border-green-200' :
                    analysisResults.riskLevel === 'Medium' ? 'bg-yellow-50 border border-yellow-200' :
                    'bg-red-50 border border-red-200'
                  }`}>
                    <div className="flex items-center mb-2">
                      {analysisResults.riskLevel === 'Low' ? (
                        <CheckCircle className="h-5 w-5 text-green-600 mr-2" />
                      ) : (
                        <AlertCircle className="h-5 w-5 text-yellow-600 mr-2" />
                      )}
                      <span className="font-semibold">
                        Risk Level: {analysisResults.riskLevel}
                      </span>
                    </div>
                    <p className="text-sm text-gray-600">
                      Confidence: {analysisResults.confidence}%
                    </p>
                  </div>

                  <div>
                    <h4 className="font-semibold text-gray-900 mb-2">Primary Concerns:</h4>
                    <ul className="space-y-1">
                      {analysisResults.primaryConcerns.map((concern: string, index: number) => (
                        <li key={index} className="text-sm text-gray-700 flex items-center">
                          <div className="h-1.5 w-1.5 bg-red-400 rounded-full mr-2"></div>
                          {concern}
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div>
                    <h4 className="font-semibold text-gray-900 mb-2">Recommendations:</h4>
                    <ul className="space-y-1">
                      {analysisResults.recommendations.map((rec: string, index: number) => (
                        <li key={index} className="text-sm text-gray-700 flex items-center">
                          <div className="h-1.5 w-1.5 bg-blue-400 rounded-full mr-2"></div>
                          {rec}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              )}
            </div>

            {/* Quick Status */}
            <div className="bg-white rounded-xl shadow-sm p-6">
              <h3 className="font-semibold text-gray-900 mb-4">Parameter Status</h3>
              <div className="space-y-3">
                {Object.entries(vitalSigns).map(([key, value]) => {
                  if (!value) return null;
                  const status = getVitalSignStatus(key, value);
                  return (
                    <div key={key} className="flex items-center justify-between">
                      <span className="text-sm text-gray-700 capitalize">
                        {key.replace(/([A-Z])/g, ' $1').trim()}
                      </span>
                      <div className={`h-2 w-2 rounded-full bg-${status.color}-500`}></div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DiagnosticInterface;